﻿/*
 * Created by nxtSTUDIO.
 * User: dmidro
 * Date: 9/30/2018
 * Time: 3:12 PM
 * 
 */

using System;
using System.Drawing;

using NxtControl.GuiFramework;


namespace HMI.Main.Canvases
{
	/// <summary>
	/// Description of Canvas1.
	/// </summary>
	public partial class Canvas1 : NxtControl.GuiFramework.HMICanvas
	{
		public Canvas1()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
		}
	}
}
