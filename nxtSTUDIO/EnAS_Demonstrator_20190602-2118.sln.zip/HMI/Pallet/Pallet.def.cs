﻿/*
 * Created by nxtSTUDIO.
 * User: Aalto_IT
 * Date: 10/7/2016
 * Time: 2:36 AM
 * 
 */
using System;
using NxtControl.GuiFramework;
using NxtControl.Services;

#region Definitions;

#endregion Definitions;
