﻿/*
 * Created by nxtSTUDIO.
 * User: Aalto_IT
 * Date: 9/30/2016
 * Time: 2:41 AM
 * 
 */
using System;
using NxtControl.GuiFramework;
using NxtControl.Services;

#region Definitions;

#endregion Definitions;
