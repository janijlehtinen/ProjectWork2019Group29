using System;
using NxtControl.GuiFramework;
using NxtControl.Services;


#region Definitions;
#region StartPauseResetButtons_HMI;
#endregion StartPauseResetButtons_HMI;

#endregion Definitions;

