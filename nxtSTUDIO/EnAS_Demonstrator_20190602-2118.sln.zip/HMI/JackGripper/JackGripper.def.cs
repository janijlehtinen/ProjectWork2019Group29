﻿/*
 * Created by nxtSTUDIO.
 * User: Aalto_IT
 * Date: 10/17/2016
 * Time: 11:17 PM
 * 
 */
using System;
using NxtControl.GuiFramework;
using NxtControl.Services;

#region Definitions;

#endregion Definitions;
