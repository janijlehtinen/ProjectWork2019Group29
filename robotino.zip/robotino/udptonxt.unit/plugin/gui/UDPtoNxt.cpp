#include "UDPtoNxt.h"

UDPtoNxt::UDPtoNxt (plugin::gui::UnitDelegate& del)
: plugin::gui::UnitDialog(del)
{
	// If the dialog is supposed to be notified when a input's, output's or state variable's value changes,
	// just uncomment the corresponding line below and modify the update() method.

	//del.registerInput("x", 1);
	//del.registerInput("y", 1);
	//del.registerInput("pose", 1);
	//del.registerInput("in0", 1);
	//del.registerInput("in1", 1);
	//del.registerInput("in2", 1);
	//del.registerInput("in3", 1);
	//del.registerInput("in4", 1);
	//del.registerInput("in5", 1);
	//del.registerInput("in6", 1);
	//del.registerInput("in7", 1);
	//del.registerInput("in8", 1);
	//del.registerOutput("out0", 1);
	//del.registerOutput("out1", 1);
	//del.registerOutput("out2", 1);
	//del.registerOutput("out3", 1);
	//del.registerOutput("out4", 1);
	//del.registerOutput("out5", 1);
	//del.registerOutput("out6", 1);
	//del.registerOutput("out7", 1);
	//del.registerOutput("out8", 1);

}

void UDPtoNxt::update (const plugin::gui::UnitHistoryBundle& buf)
{
	//plugin::gui::VariableHistoryBuffer* i_x = buf.getInputHistory("x");
	//if (i_x) { }
	//plugin::gui::VariableHistoryBuffer* i_y = buf.getInputHistory("y");
	//if (i_y) { }
	//plugin::gui::VariableHistoryBuffer* i_pose = buf.getInputHistory("pose");
	//if (i_pose) { }
	//plugin::gui::VariableHistoryBuffer* i_in0 = buf.getInputHistory("in0");
	//if (i_in0) { }
	//plugin::gui::VariableHistoryBuffer* i_in1 = buf.getInputHistory("in1");
	//if (i_in1) { }
	//plugin::gui::VariableHistoryBuffer* i_in2 = buf.getInputHistory("in2");
	//if (i_in2) { }
	//plugin::gui::VariableHistoryBuffer* i_in3 = buf.getInputHistory("in3");
	//if (i_in3) { }
	//plugin::gui::VariableHistoryBuffer* i_in4 = buf.getInputHistory("in4");
	//if (i_in4) { }
	//plugin::gui::VariableHistoryBuffer* i_in5 = buf.getInputHistory("in5");
	//if (i_in5) { }
	//plugin::gui::VariableHistoryBuffer* i_in6 = buf.getInputHistory("in6");
	//if (i_in6) { }
	//plugin::gui::VariableHistoryBuffer* i_in7 = buf.getInputHistory("in7");
	//if (i_in7) { }
	//plugin::gui::VariableHistoryBuffer* i_in8 = buf.getInputHistory("in8");
	//if (i_in8) { }
	//plugin::gui::VariableHistoryBuffer* o_out0 = buf.getOutputHistory("out0");
	//if (o_out0) { }
	//plugin::gui::VariableHistoryBuffer* o_out1 = buf.getOutputHistory("out1");
	//if (o_out1) { }
	//plugin::gui::VariableHistoryBuffer* o_out2 = buf.getOutputHistory("out2");
	//if (o_out2) { }
	//plugin::gui::VariableHistoryBuffer* o_out3 = buf.getOutputHistory("out3");
	//if (o_out3) { }
	//plugin::gui::VariableHistoryBuffer* o_out4 = buf.getOutputHistory("out4");
	//if (o_out4) { }
	//plugin::gui::VariableHistoryBuffer* o_out5 = buf.getOutputHistory("out5");
	//if (o_out5) { }
	//plugin::gui::VariableHistoryBuffer* o_out6 = buf.getOutputHistory("out6");
	//if (o_out6) { }
	//plugin::gui::VariableHistoryBuffer* o_out7 = buf.getOutputHistory("out7");
	//if (o_out7) { }
	//plugin::gui::VariableHistoryBuffer* o_out8 = buf.getOutputHistory("out8");
	//if (o_out8) { }

}

void UDPtoNxt::translate (void)
{	
}

